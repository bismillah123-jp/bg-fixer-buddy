import { StockDashboard } from "@/components/StockDashboard";
import { Footer } from "@/components/Footer";

const Index = () => {
  return (
    <>
      <StockDashboard />
      <Footer />
    </>
  );
};

export default Index;
